<?php

// connection
define("HOST", "localhost");
define("UNAME", "root");
define("PASS", "");
define("DB", "tokobuku");

// tables
// define("TB_BARANG", "tb_barang");

?>